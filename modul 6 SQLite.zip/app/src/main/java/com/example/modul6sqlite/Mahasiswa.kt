package com.example.modul6sqlite

data class Mahasiswa(val email: String,val nama: String,val nim: String,val password:String)
