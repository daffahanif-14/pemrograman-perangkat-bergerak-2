package com.example.modul6sqlite

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.modul6sqlite.databinding.LisItemBinding

class MahassiswaAdapter (private val context: Context, private var ListMahasiswa:ArrayList<Mahasiswa>) :RecyclerView.Adapter<MahassiswaAdapter.ViewHolder>(){
    class ViewHolder (val binding: LisItemBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LisItemBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return ViewHolder(view)
    }
    override fun getItemCount(): Int {
        return ListMahasiswa.size
    }
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.binding.txtNama.text = ListMahasiswa[position].nama
        holder.binding.txtEmail.text = ListMahasiswa[position].email
        holder.binding.cardview.setOnClickListener {
            val intent = Intent(context,UpdateActivity::class.java)
            intent.putExtra("nim",ListMahasiswa[position].nim)
            intent.putExtra("nama",ListMahasiswa[position].nama)
            intent.putExtra("email",ListMahasiswa[position].email)
            intent.putExtra("password",ListMahasiswa[position].password)
            context.startActivity(intent)
        }
    }
    fun updateData(newListMahasiswa: ArrayList<Mahasiswa>){
        ListMahasiswa = newListMahasiswa
        notifyDataSetChanged()
    }
}