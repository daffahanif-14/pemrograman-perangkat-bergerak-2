package com.example.modul6sqlite

import android.app.Activity
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import com.example.modul6sqlite.databinding.ActivityUpdateBinding

class UpdateActivity : AppCompatActivity() {
    lateinit var binding: ActivityUpdateBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUpdateBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val nim = intent.getStringExtra("nim")!!
        val nama = intent.getStringExtra("nama")!!
        val email = intent.getStringExtra("email")!!
        val password = intent.getStringExtra("password")!!

        val mahasiswa = Mahasiswa(email, nama, nim, password)

        binding.InputNim.setText(mahasiswa.nim)
        binding.InputNama.setText(mahasiswa.nama)
        binding.InputEmail.setText(mahasiswa.email)
        binding.InputPassword.setText(mahasiswa.password)

        binding.btnDelete.setOnClickListener (){
            val db = MahasiswaHelper(this)
            db.hapusData(mahasiswa.email)
            setResult(Activity.RESULT_OK)
            finish()
        }
        binding.btnUpdate.setOnClickListener (){
            val updateMahasiswa = Mahasiswa (
                binding.InputEmail.text.toString(),
                binding.InputNama.text.toString(),
                binding.InputNim.text.toString(),
                binding.InputPassword.text.toString()
            )
            val db = MahasiswaHelper(this)
            db.updateData(updateMahasiswa)
            setResult(Activity.RESULT_OK)
            finish()
        }
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when(item.itemId){
            android.R.id.home -> {
                onBackPressed()
                true
            }else -> super.onOptionsItemSelected(item)
        }
    }
}